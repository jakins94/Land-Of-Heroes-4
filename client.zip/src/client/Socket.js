import config from './config/config';
import PH from './PlayerHandler';
import { newChat } from './ChatHandler';
import io from 'socket.io-client';

let mySocket;

export function sendMovement(x, y, pid) {
    mySocket.emit('player move', {x: x, y: y})
}

export function sendHeartbeat(id) {
    mySocket.emit('player heartbeat', { id: mySocket.id });
}

export function requestPlayers() {
    mySocket.emit('request players');
}

export function sendChatMessage(msg) {
    mySocket.emit('chat message', { msg: msg });
}

export function socketConnect() {
    mySocket = io.connect(config.ip);
    mySocket.on('userConnected', (p) => PH.userReceived(p));
    mySocket.on('playerConnected', (p) => PH.playerReceived(p));
    mySocket.on('playersConnected', (p) => PH.playersReceived(p));
    mySocket.on('playerMove', (p) => PH.playerMove(p));
    mySocket.on('removePlayer', (p) => PH.removePlayer(p));
    mySocket.on('new message', (p) => PH.newChat(p));
}

export function returnSocket() {
    return mySocket;
}