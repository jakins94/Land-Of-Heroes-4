import 'phaser';
import Player from '../Player';
import { socketConnect, sendHeartbeat, sendMovement } from '../Socket';
import io from 'socket.io-client';
import PH from '../PlayerHandler';

let localPlayer;

export function myPlayer() {
    return localPlayer;
}

// when the user connects
export function newUser(p) {

    let phaser = window.game;
    let scene = phaser.scene.getScene('Game');

    let newPlayer = new Player(p.name, p.pid, p.x, p.y, p.mapId);
        newPlayer.sprite = scene.physics.add.sprite(400, 150, 'knight');
        newPlayer.sprite.setScale(0.7, 0.7);
        newPlayer.chatSprite = scene.physics.add.sprite(400, 150, 'chatBubble');
        newPlayer.chatSprite.alpha = 0;
        newPlayer.sprite.anims.play('idle', true);
        newPlayer.chatText = scene.add.bitmapText(0, 0, 'prstart', '');
        newPlayer.chatText.tint = 0x222222;
        newPlayer.chatText.setFontSize(Math.round((scene.cameras.main.width / 175) + (scene.cameras.main.height / 130)));


        myPlayer = newPlayer;
        scene.cameras.main.startFollow(newPlayer.sprite, false, 0.08, 0.08);
        scene.cameras.main.setZoom(1.5);

        console.log(newPlayer.pid)

        return newPlayer;
};

//when another player connects
export function newPlayer(p) {

    let phaser = window.game;
    let scene = phaser.scene.getScene('Game');

    let newPlayer = new Player(p.name, p.pid, p.x, p.y, p.mapId);
        newPlayer.sprite = scene.physics.add.sprite(400, 150, 'knight');
        newPlayer.sprite.setScale(0.7, 0.7);
        newPlayer.sprite.anims.play('idle', true);
        newPlayer.chatSprite = scene.physics.add.sprite(400, 150, 'chatBubble');
        newPlayer.chatSprite.alpha = 0;
        newPlayer.chatText = scene.add.bitmapText(0, 0, 'prstart', '');
        newPlayer.chatText.tint = 0x222222;

        newPlayer.chatText.setFontSize(Math.round((scene.cameras.main.width / 175) + (scene.cameras.main.height / 130)));


        return newPlayer;
};
 
export default class GameScene extends Phaser.Scene {
    constructor() {
        super('Game');

        this.zoomLevel = 0;
    }

    preload() {
        this.load.spritesheet('knight', 'assets/sprites/player_sprites/knight.png',
                              {frameWidth: 108, frameHeight: 108});

        this.load.tilemapTiledJSON('map', 'assets/maps/newmap.json');
        this.load.image('tiles1', 'assets/sprites/tilesets/mountain-ex.png');

        this.load.image('chatBubble', 'assets/sprites/player_sprites/chat_bubble.png');
    }

    create() {

        // for multi-touch events (camera zoom)
        this.input.addPointer(1);

        let preloadKnight = this.add.sprite(0, 0, 'knight');
            preloadKnight.alpha = 0;

        // set world and camera bounds, 100x100 map is 3200x3200
        this.cameras.main.setBounds(0, 0, 3200, 3200);
        this.physics.world.setBounds(0, 0, 3200, 3200);

        // add invisible background
        let bg = this.physics.add.sprite(0, 0).setInteractive();
        bg.fixedToCamera = true;
        bg.setScale(3200, 3200);

        // init map
        let map = this.make.tilemap({ key: 'map' });
        let tileset = map.addTilesetImage('mountain', 'tiles1', 32, 32, 1, 2);
        let ground = map.createStaticLayer('ground', tileset, 0, 0);
        let layer1 = map.createStaticLayer('layer1', tileset, 0, 0);
        let layer2 = map.createStaticLayer('layer2', tileset, 0, 0);
        let layer3 = map.createStaticLayer('layer3', tileset, 0, 0);
        let objects = map.createStaticLayer('objects', tileset, 0, 0);

        this.anims.create({
            key: 'idle',
            frames: this.anims.generateFrameNumbers('knight', { start: 10, end: 13 }),
            frameRate: 6,
            repeat: -1
        });

        this.anims.create({
            key: 'walk',
            frames: this.anims.generateFrameNumbers('knight', { start: 0, end: 5 }),
            frameRate: 10,
            repeat: -1
        });

        // camera zoom variables
        let zoomLevel = 0,
            zoomMin = -0.5,
            zoomMax = 1.5;

        this.input.on('wheel', (pointer, gameObjects, deltaX, deltaY, deltaZ) => {
            // update zoom level
            zoomLevel -= deltaY * 0.001;
            // prevents from zooming out too far
            if(zoomLevel < zoomMin) zoomLevel = zoomMin;
            if(zoomLevel > zoomMax) zoomLevel = zoomMax;

            this.cameras.main.setZoom(zoomLevel + 1.5);
        });

        socketConnect();

        // when you click the invisible background it gets cursor position relative to the map
        bg.on('pointerdown', () => {
            
            //let client = io();

            this.scale.startFullscreen();
            //console.log(this.scale.fullscreen)
            //console.log(this.scale.isFullscreen)
            //if(!this.scale.isFullscreen) {
                //let inputBox = document.getElementById('chat');
                //inputBox.requestFullscreen({preventScroll: true});
            //}

            let clickX = this.input.activePointer.worldX;
            let clickY = this.input.activePointer.worldY;
            sendMovement(clickX, clickY, 1);
            //io().emit('player move', { x: clickX, y: clickY });

            /*localPlayer.movingX = this.input.activePointer.worldX;
            localPlayer.movingY = this.input.activePointer.worldY;
            this.physics.moveTo(localPlayer.sprite, localPlayer.movingX, localPlayer.movingY, 100);
            if(localPlayer.movingX > localPlayer.sprite.body.x) {
                localPlayer.sprite.flipX = false;
            } else {
                localPlayer.sprite.flipX = true;
            }*/
        });

        let heartbeatLoop = setInterval(sendHeartbeat, 5000);

    }

    render() {
        	this.game.debug.cameraInfo(this.game.camera, 32, 32);
    }

    distance(x1, y1, x2, y2) {
        return Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
    }

    update() {

        if(this.input.pointer1.isDown && this.input.pointer2.isDown) {

            let zoomLevel = 0,
                zoomMin = -0.5,
                zoomMax = 1.5,
                distanceMultiplier = 0.0075;

            zoomLevel = (this.distance(this.input.pointer1.x, this.input.pointer1.y, this.input.pointer2.x, this.input.pointer2.y)) * distanceMultiplier;

            if(zoomLevel < zoomMin) zoomLevel = zoomMin;
            if(zoomLevel > zoomMax) zoomLevel = zoomMax;

            this.cameras.main.setZoom(zoomLevel + 1.5);

        }

        for(let i=0;i<PH.playerList().length;i++) {
            let thisPlayer = PH.playerList()[i];
            if(thisPlayer) {
                if(!thisPlayer.sprite) {
                    break;
                }
                if(thisPlayer.distance(thisPlayer.sprite.x, thisPlayer.sprite.y, thisPlayer.movingX, thisPlayer.movingY) <= 20) {
                    thisPlayer.moving = false;
                    thisPlayer.sprite.setVelocityX(0);
                    thisPlayer.sprite.setVelocityY(0);
                } else {
                    this.physics.moveTo(thisPlayer.sprite, thisPlayer.movingX, thisPlayer.movingY, 100);
                    thisPlayer.moving = true;
                }

                if(thisPlayer.moving) {
                    thisPlayer.sprite.anims.play('walk', true);
                } else {
                    thisPlayer.sprite.anims.play('idle', true);
                }

                if(thisPlayer.lastChatText != '') {
                    thisPlayer.chatText.text = thisPlayer.lastChatText;

                    thisPlayer.chatSprite.body.x = Math.round(thisPlayer.sprite.body.x + 65);
                    thisPlayer.chatSprite.body.y = Math.round(thisPlayer.sprite.body.y - 70);
                    thisPlayer.chatSprite.displayWidth = 100;
                    thisPlayer.chatSprite.displayHeight = 75;
                    thisPlayer.chatText.x = Math.round(thisPlayer.sprite.body.x + 75);
                    thisPlayer.chatText.y = Math.round(thisPlayer.sprite.body.y - 60);
                    let fontWeight = 225;
                    let screenRatio = this.cameras.main.width / this.cameras.main.height;
                    thisPlayer.chatText.setFontSize(Math.round((this.cameras.main.width / fontWeight) + (this.cameras.main.height / (fontWeight / screenRatio))));
                    console.log(thisPlayer.chatText.width)
                    //thisPlayer.chatText.setOrigin(0.5);
                    thisPlayer.chatSprite.alpha = 1;
                    if(thisPlayer.lastChatTime < Date.now() - 7000) {
                        thisPlayer.lastChatText = '';
                        thisPlayer.chatText.text = '';
                        thisPlayer.chatSprite.alpha = 0;
                    }
                }
            }
            
        }

        /*if(localPlayer) {
            // if player reaches destination, stop moving
            if(localPlayer.distance(localPlayer.sprite.x, localPlayer.sprite.y, localPlayer.movingX, localPlayer.movingY) <= 20) {
                localPlayer.moving = false;
                localPlayer.sprite.setVelocityX(0);
                localPlayer.sprite.setVelocityY(0);
            } else {
                localPlayer.moving = true;
            }

            if(localPlayer.moving) {
                localPlayer.sprite.anims.play('walk', true);
            } else {
                localPlayer.sprite.anims.play('idle', true);
            }

        }*/

    }

}