import { newPlayer, newUser } from './scenes/GameScene';
import { requestPlayers } from './Socket';
import { newMessage } from './ChatHandler';

let players = [];

export default {

    playerList() {
        return players;
    },
    
    // the user (client) is received
    userReceived(p) {
        let player = newUser(p);
        players.push(player);
        requestPlayers();
    },

    newChat(data) {
        let player = this.playerByPid(data.id);

        if(!player) return;

        let maxLength = 13;
        let maxLines = 4;

        let thisChat = data.name + ': ' + data.msg;
        let newMsg = '';

        let numLines = thisChat.length / maxLength;

        for(let i=0;i<numLines;i++) {
            newMsg += thisChat.slice(0+(i*maxLength), maxLength+(i*maxLength)) + '-\n';
        }

        //if(thisChat.length > maxLength) {
        //    newMsg = thisChat.slice(0, maxLength) + '\n' + thisChat.slice(maxLength);
        //}
        
        player.lastChatText = newMsg;

        player.lastChatTime = Date.now();

    // sends data to ChatHandler also
        newMessage(data);
    },

    // one new player is received
    playerReceived(p) {
        let player = newPlayer(p);
        players.push(player);
    },

    // multiple new players received
    playersReceived(p) {
        for(let i=0;i<p.players.length;i++) {
            let exists = false;
            for(let x=0;x<players.length;x++) {
                if(players[x].pid == p.players[i].pid) {
                    exists = true;
                }
            }
            //only add new player if it doesn't already exist
            if(!exists) {
                let player = newPlayer(p.players[i]);
                players.push(player);
            }
        }
    },

    removePlayer(p) {
        let thisPlayer = this.playerByPid(p.pid);
        console.log(p)
        if(thisPlayer) {
            for(let i=0;i<players.length;i++) {
                if(players[i].pid == p.pid) {
                    players[i].sprite.destroy();
                    players.splice(i, 1);
                    console.log(players)
                }
            }
        }
    },

    playerMove(p) {
        let thisPlayer = this.playerByPid(p.pid);
        if(!thisPlayer)
            return;
        thisPlayer.movingX = p.x;
        thisPlayer.movingY = p.y;

        //let phaser = window.game;
        //let scene = phaser.scene.GetScene('Game');
        //phaser.physics.moveTo(thisPlayer.sprite, thisPlayer.movingX, thisPlayer.movingY, 100);

    },
    
    playerByPid(id) {
        for(let i=0;i<players.length;i++) {
            var p = players[i];
            if(p.pid == id) {
                return p;
            }
        }
        return false;
    }

    /*sendNewPlayer() {
        console.log(index.mySocket())
        index.mySocket().emit('receivedNewPlayer', {socket : socket });
    }*/
}