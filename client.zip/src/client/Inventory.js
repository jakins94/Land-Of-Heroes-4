import 'phaser';

export class InvScene extends Phaser.Scene {

    constructor() {
        super('Inv');

        this.inventoryOpen = false;
        this.invWidthScale = 0.35;
    }

    preload() {

        this.load.image('invSlot', 'assets/sprites/icons/inventorySlot.png');
        this.load.image('deleteIcon', 'assets/sprites/icons/deleteIcon.png');
        this.load.image('invBack', 'assets/sprites/icons/inventoryBack.png');
        this.load.image('bronzeSword', 'assets/sprites/items/bronzeSword.png');
        this.load.image('bronzeHelm', 'assets/sprites/items/bronzeHelm.png');
        this.load.image('bronzeLegs', 'assets/sprites/items/bronzeLegs.png');
        this.load.image('cape', 'assets/sprites/items/cape.png');
        this.load.image('ring', 'assets/sprites/items/ring.png');
        this.load.image('necklace', 'assets/sprites/items/necklace.png');
        this.load.image('coins', 'assets/sprites/items/coins.png');

        this.load.bitmapFont('prstart', 'assets/fonts/test/font.png', 'assets/fonts/test/font.fnt');

    }

    create() {

        this.invBack = this.add.sprite(0, 0, 'invBack');
        this.invBack.setOrigin(0);
        this.invBack.alpha = 0.35;
        this.invBack.tint = 0x000000;
        this.invBack2 = this.add.sprite(0, 0, 'invBack');
        this.invBack2.setOrigin(0);
        this.invBack2.alpha = 0.35;

        this.nameBox = this.add.sprite(0, 0, 'invSlot');
        this.nameBox.setOrigin(0);
        this.nameBox.alpha = 0.4;

        this.nameBox2 = this.add.sprite(0, 0, 'invSlot');
        this.nameBox2.alpha = 0.4;
        this.nameBox2.setOrigin(0);
        this.nameBox.tint = 0x000000;

        this.invNameStyle = { font: "24px prstartk", fill: "white" };
        this.nameText = this.add.bitmapText(0, 0, 'prstart', 'Inventory');

        this.statBox = this.add.sprite(0, 0, 'invSlot');
        this.statBox.setOrigin(0);
        this.statBox.alpha = 0.4;
        this.statBox.tint = 0x000000;

        this.statBox2 = this.add.sprite(0, 0, 'invSlot');
        this.statBox2.setOrigin(0);
        this.statBox2.alpha = 0.4;

        this.deleteIcon = this.add.sprite(0, 0, 'deleteIcon');
        this.deleteIcon.alpha = 0.6;
        this.deleteIcon.setOrigin(0);

        this.itemText = this.add.bitmapText(0, 0, 'prstart', 'Bronze Sword');
        this.itemText.setOrigin(0.5);

        let statsTextTest = 'Damage: 2-4\nAccuracy: 4\n+1 to Strength';
        this.statsText = this.add.bitmapText(0, 0, 'prstart', statsTextTest);

        this.useBox1 = this.add.sprite(0, 0, 'invSlot');
        this.useBox1.alpha = 0.3;
        this.useBox1.tint = 0x000000;
        this.useBox1.setOrigin(0);
        this.useBox2 = this.add.sprite(0, 0, 'invSlot');
        this.useBox2.alpha = 0.3;
        this.useBox2.tint = 0x000000;
        this.useBox2.setOrigin(0);

        this.useText1 = this.add.bitmapText(0, 0, 'prstart', 'Use');
        this.useText1.setOrigin(0.5);
        this.useText2 = this.add.bitmapText(0, 0, 'prstart', 'Equip');
        this.useText2.setOrigin(0.5);


        this.itemSpacing = 4;
        this.totalItems = 30;

        this.itemSlot = [];
        this.itemSlot2 = [];

        this.myItems = ['bronzeHelm', 'bronzeLegs', 'bronzeSword'];
        this.myInv = [];

        this.invSlotSelected = {
            itemName: 'Bronze Sword',
            itemSprite: 'bronzeSword',
            options: {
                1: 'Equip',
                2: 'Drop'
            }
        }

        this.selectedItemSprite = this.add.sprite(0, 0, 'bronzeSword');
        this.selectedItemSprite.setOrigin(0);

        for (let i = 0; i < this.totalItems; i++) {

            this.itemSlot[i] = this.add.sprite(0, 0, 'invSlot');
            this.itemSlot[i].setOrigin(0);
            this.itemSlot[i].alpha = 0.4;
            this.itemSlot[i].tint = 0x000000;
            this.itemSlot2[i] = this.add.sprite(0, 0, 'invSlot');
            this.itemSlot2[i].setOrigin(0);
            this.itemSlot2[i].alpha = 0.4;

            if (this.myItems[i]) {
                this.myInv[i] = this.add.sprite(0, 0, this.myItems[i]);
                this.myInv[i].setOrigin(0);
            }

            this.itemSlot2[i].on('pointerover', () => {
                this.itemSlot[i].alpha = 0.65;
            });
            this.itemSlot2[i].on('pointerout', () => {
                this.itemSlot[i].alpha = 0.4;
            });
        }


        this.input.setDefaultCursor('url(assets/sprites/icons/cursor.png), pointer');

        this.nameBox2.on('pointerover', () => {
            this.nameBox.alpha = 0.65;
        });
        this.nameBox2.on('pointerout', () => {
            this.nameBox.alpha = 0.4;
        });
        this.statBox2.on('pointerover', () => {
            this.statBox.alpha = 0.65;
        });
        this.statBox2.on('pointerout', () => {
            this.statBox.alpha = 0.4;
        });

        this.input.keyboard.on('keydown', (event) => {
            if (event.code == 'KeyI') {
                this.toggleInventory();
            }
        });

        this.startInventory();
    }

    resizeInventory() {
        this.invWidth = this.cameras.main.width * this.invWidthScale; // inventory width is 30% of game screen
        this.invStartX = this.cameras.main.width - this.invWidth; // where inventory starts

        this.nameBoxStartX = this.invStartX + 10;
        this.nameBoxStartY = this.cameras.main.height * 0.025;
        this.nameBoxWidth = this.invWidth - 20;
        this.nameBoxHeight = this.cameras.main.height * 0.05;

        this.statBoxStartX = this.invStartX + 10;
        this.statBoxStartY = this.nameBoxStartY + this.nameBoxHeight + (this.cameras.main.height * 0.02);
        this.statBoxWidth = this.invWidth - 20;
        this.statBoxHeight = this.cameras.main.height * 0.25;

        this.useBox1StartX = this.invStartX + 10;
        this.useBox1StartY = this.statBoxStartY + this.statBoxHeight - (this.statBoxHeight * 0.22) - 4;
        this.useBox1Width = (this.statBoxWidth / 2) - 2;
        this.useBox1Height = this.statBoxHeight * 0.22;

        this.useBox2StartX = this.invStartX + 10 + (this.statBoxWidth / 2) - 1;
        this.useBox2StartY = this.statBoxStartY + this.statBoxHeight - (this.statBoxHeight * 0.22) - 4;
        this.useBox2Width = (this.statBoxWidth / 2) - 2;
        this.useBox2Height = this.statBoxHeight * 0.22;

        this.itemStartX = this.statBoxStartX;
        this.itemStartY = this.statBoxStartY + this.statBoxHeight + (this.cameras.main.height * 0.02);
        this.itemWidth = ((this.statBoxWidth - (this.itemSpacing * 5)) / 6);
        this.itemHeight = this.itemWidth;

        this.deleteStartX = this.statBoxStartX + this.statBoxWidth - (this.statBoxHeight * 0.3);
        this.deleteStartY = this.statBoxStartY + 4;
        this.deleteWidth = this.statBoxHeight * 0.25;
        this.deleteHeight = this.statBoxHeight * 0.25;

        this.invBack.x = this.invStartX;
        this.invBack.displayWidth = this.cameras.main.width * this.invWidthScale;
        this.invBack.displayHeight = this.cameras.main.height;
        this.invBack2.x = this.invStartX + 1;
        this.invBack2.displayWidth = this.cameras.main.width * this.invWidthScale;
        this.invBack2.displayHeight = this.cameras.main.height;

        this.nameBox.x = this.nameBoxStartX;
        this.nameBox.y = this.nameBoxStartY;
        this.nameBox.displayWidth = this.nameBoxWidth;
        this.nameBox.displayHeight = this.nameBoxHeight;
        this.nameBox2.x = this.nameBoxStartX - 2;
        this.nameBox2.y = this.nameBoxStartY - 2;
        this.nameBox2.displayWidth = this.nameBoxWidth;
        this.nameBox2.displayHeight = this.nameBoxHeight;

        this.statBox.x = this.statBoxStartX;
        this.statBox.y = this.statBoxStartY;
        this.statBox.displayWidth = this.statBoxWidth;
        this.statBox.displayHeight = this.statBoxHeight;
        this.statBox2.x = this.statBoxStartX - 2;
        this.statBox2.y = this.statBoxStartY - 2;
        this.statBox2.displayWidth = this.statBoxWidth;
        this.statBox2.displayHeight = this.statBoxHeight;

        this.useBox1.x = this.useBox1StartX;
        this.useBox1.y = this.useBox1StartY;
        this.useBox1.displayWidth = this.useBox1Width;
        this.useBox1.displayHeight = this.useBox1Height;

        this.useBox2.x = this.useBox2StartX;
        this.useBox2.y = this.useBox2StartY;
        this.useBox2.displayWidth = this.useBox2Width;
        this.useBox2.displayHeight = this.useBox2Height;

        this.deleteIcon.x = this.deleteStartX;
        this.deleteIcon.y = this.deleteStartY;
        this.deleteIcon.displayWidth = this.deleteWidth;
        this.deleteIcon.displayHeight = this.deleteHeight;

        this.nameText.setFontSize(Math.round((this.cameras.main.width / 70) + (this.cameras.main.height / 55)));
        this.nameText.setOrigin(0.5);
        this.nameText.x = Math.round(this.nameBoxStartX + (this.nameBoxWidth / 2));
        this.nameText.y = Math.round(this.nameBoxStartY + (this.nameBoxHeight / 2));

        this.itemText.setFontSize(Math.round((this.cameras.main.width / 120) + (this.cameras.main.height / 90)));
        this.itemText.setOrigin(0);
        this.itemText.x = this.statBoxStartX + (this.statBoxWidth * 0.02);
        this.itemText.y = this.statBoxStartY + (this.statBoxHeight * 0.02);

        this.statsText.setFontSize(Math.round((this.cameras.main.width / 140) + (this.cameras.main.height / 110)));
        this.statsText.setOrigin(0);
        this.statsText.x = Math.round(this.statBoxStartX + (this.statBoxWidth / 4));
        this.statsText.y = Math.round(this.statBoxStartY + (this.statBoxHeight * .175));

        //this.useText1.setFontSize(Math.round((this.cameras.main.width / 80) + (this.cameras.main.height / 60)));
        this.useText1.setFontSize(Math.round((this.cameras.main.width / 100) + (this.cameras.main.height / 80)));
        this.useText1.setOrigin(0.5);
        this.useText1.x = this.statBoxStartX + (this.statBoxWidth * 0.25);
        this.useText1.y = this.statBoxStartY + this.statBoxHeight - (this.statBoxHeight * .135);

        this.useText2.setFontSize(Math.round((this.cameras.main.width / 100) + (this.cameras.main.height / 80)));
        this.useText2.setOrigin(0.5);
        this.useText2.x = this.statBoxStartX + (this.statBoxWidth * 0.75);
        this.useText2.y = this.statBoxStartY + this.statBoxHeight - (this.statBoxHeight * .135);

        this.selectedItemSprite.x = this.statBoxStartX + (this.statBoxWidth * 0.01);
        this.selectedItemSprite.y = this.statBoxStartY + (this.statBoxHeight * 0.15);
        this.selectedItemSprite.displayWidth = this.statBoxWidth / 4;
        this.selectedItemSprite.displayHeight = this.statBoxWidth / 4;


        let currSlotX = this.itemStartX,
            currSlotY = this.itemStartY;

        for (let i = 0; i < this.totalItems; i++) {
            if (currSlotX >= this.statBoxStartX + this.statBoxWidth - 4) {
                currSlotX = this.itemStartX;
                currSlotY += this.itemSpacing + this.itemHeight;
            }

            this.itemSlot[i].x = currSlotX;
            this.itemSlot[i].y = currSlotY;
            this.itemSlot[i].displayWidth = this.itemWidth;
            this.itemSlot[i].displayHeight = this.itemHeight;
            this.itemSlot2[i].x = currSlotX - 2;
            this.itemSlot2[i].y = currSlotY - 2;
            this.itemSlot2[i].displayWidth = this.itemWidth;
            this.itemSlot2[i].displayHeight = this.itemHeight;

            if (this.myInv[i]) {
                this.myInv[i].x = currSlotX - 2;
                this.myInv[i].y = currSlotY - 2;
                this.myInv[i].displayWidth = this.itemWidth;
                this.myInv[i].displayHeight = this.itemHeight;
            }

            currSlotX += this.itemSpacing + this.itemWidth;
        }
    }

    update() {
        // resize the inventory if size of the game screen has changed
        if ((this.cameras.main.width * this.invWidthScale) != this.invWidth || this.cameras.main.height != this.invBack.displayHeight) {
            this.resizeInventory();
        }
    }

    startInventory() {
        this.scene.get('Inv');
        this.scene.setVisible(false, 'Inv');
        this.statBox2.removeInteractive();
        this.nameBox2.removeInteractive();
        for (let i = 0; i < this.totalItems; i++) {
            this.itemSlot2[i].removeInteractive();
        }
    }

    toggleInventory() {

        if (this.inventoryOpen) {
            this.inventoryOpen = false;
            this.statBox2.removeInteractive();
            this.nameBox2.removeInteractive();
            for (let i = 0; i < this.totalItems; i++) {
                this.itemSlot2[i].removeInteractive();
            }
            this.scene.get('Inv');
            this.scene.setVisible(false, 'Inv');
        } else {
            this.resizeInventory();
            this.inventoryOpen = true;
            this.scene.get('Inv');
            this.scene.setVisible(true, 'Inv');
            this.statBox2.setInteractive();
            this.nameBox2.setInteractive();
            for (let i = 0; i < this.totalItems; i++) {
                this.itemSlot2[i].setInteractive();
            }
        }

    }

}